All notable changes are described on the [Releases](https://github.com/reactjs/react-redux/releases) page.
