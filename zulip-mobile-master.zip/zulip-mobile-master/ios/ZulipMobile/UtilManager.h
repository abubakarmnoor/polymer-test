//
//  UtilManager.h
//  ZulipMobile
//

#import <React/RCTBridgeModule.h>

@interface UtilManager : NSObject <RCTBridgeModule>
@end
