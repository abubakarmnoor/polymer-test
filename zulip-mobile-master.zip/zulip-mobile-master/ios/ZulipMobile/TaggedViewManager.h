//
//  RCTViewManager+Tag.h
//  ZulipMobile
//

#import "RCTViewManager.h"

@interface TaggedViewManager : RCTViewManager

@end
