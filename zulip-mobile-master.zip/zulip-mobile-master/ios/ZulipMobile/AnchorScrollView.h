//
//  AnchorScrollView.h
//  ZulipMobile
//

#import <React/RCTScrollView.h>

@interface AnchorScrollView : RCTScrollView

@property (nonatomic, assign) BOOL autoScrollToBottom;

@end
