//
//  AnchorScrollViewManager.h
//  ZulipMobile
//

#import <React/RCTScrollViewManager.h>

@interface AnchorScrollViewManager : RCTScrollViewManager

@end
