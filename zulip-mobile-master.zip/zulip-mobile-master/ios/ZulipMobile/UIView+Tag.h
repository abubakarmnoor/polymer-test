//
//  RCTView+Tag.h
//  ZulipMobile
//

#import <UIKit/UIKit.h>

@interface UIView (Tag)

@property (nonatomic, copy) NSString *tagID;

@end
