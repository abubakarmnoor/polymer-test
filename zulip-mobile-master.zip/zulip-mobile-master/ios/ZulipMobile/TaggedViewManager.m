//
//  RCTViewManager+Tag.m
//  ZulipMobile
//

#import "TaggedViewManager.h"

@implementation TaggedViewManager

RCT_EXPORT_MODULE()

RCT_EXPORT_VIEW_PROPERTY(tagID, NSString)

@end
