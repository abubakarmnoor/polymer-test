/* @flow */
/* eslint-disable */
import { StyleSheet } from 'react-native';

export default {
  msup: StyleSheet.create({
    [0]: {},
    [1]: {
      fontSize: 12,
      lineHeight: 11,
      textAlignVertical: 'top',
    },
  }),
};
