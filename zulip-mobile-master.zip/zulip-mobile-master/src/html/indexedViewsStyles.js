/* @flow */
/* eslint-disable */
import { StyleSheet } from 'react-native';

export default {
  mfrac: StyleSheet.create({
    [0]: {
      borderBottomWidth: 1,
    },
    [1]: {},
  }),
};
