/* @flow */
export default {
  color: '#333',
  backgroundColor: 'white',
  borderColor: 'rgba(127, 127, 127, 0.25)',
  cardColor: '#F8F8F8',
};
