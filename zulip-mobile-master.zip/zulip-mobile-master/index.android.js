/* @flow */
// import './src/ReactotronConfig';

import { AppRegistry } from 'react-native';
import ZulipMobile from './src/ZulipMobile';

AppRegistry.registerComponent('ZulipMobile', () => ZulipMobile);
