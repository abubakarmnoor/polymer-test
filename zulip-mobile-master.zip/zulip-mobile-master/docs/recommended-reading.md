# Recommended reading

## React Native

We recommend just official documentation of React Native - take a look at their
[Getting started](https://facebook.github.io/react-native/docs/getting-started.html) section.


## Redux

To know and understand what actually Redux is we encourage you to watch
[this free video tutorial](https://egghead.io/lessons/javascript-redux-generating-containers-with-connect-from-react-redux-visibletodolist).


## Flexbox
Play [the game](http://flexboxfroggy.com/) and learn how Flexbox works.
