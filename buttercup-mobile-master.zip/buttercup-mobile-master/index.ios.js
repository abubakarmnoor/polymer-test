import ButtercupShared from "./index.shared.js";
import React from "react";
import { AppRegistry } from "react-native";

export default class Buttercup extends ButtercupShared {

    // Nothing here

}

AppRegistry.registerComponent('Buttercup', () => Buttercup);
