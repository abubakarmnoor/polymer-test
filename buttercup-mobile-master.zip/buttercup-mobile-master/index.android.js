import React from "react";
import { AppRegistry } from "react-native";
import ButtercupShared from "./index.shared.js";

export default class Buttercup extends ButtercupShared {

    // Nothing here

}

AppRegistry.registerComponent('Buttercup', () => Buttercup);
