import { createAction } from "redux-actions";
import {
    APP_SET_SAVING
} from "./types.js";

export const setSaving =                        createAction(APP_SET_SAVING);
