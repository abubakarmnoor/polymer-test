export default function handleStateChange(store, dispatch) {
    const state = store.getState();
    // do something?
}
