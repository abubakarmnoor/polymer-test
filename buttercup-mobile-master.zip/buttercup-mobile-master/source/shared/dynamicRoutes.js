export const EntryRouteNormalProps = {
    rightTitle: "Open",
    onRight: () => {}
}

export const EntryRouteSaveProps = {
    rightTitle: "Save",
    onRight: () => {}
}
