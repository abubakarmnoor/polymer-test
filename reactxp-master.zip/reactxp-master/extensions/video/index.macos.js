'use strict';

module.exports = require('./dist/macos/PluginBase.js');