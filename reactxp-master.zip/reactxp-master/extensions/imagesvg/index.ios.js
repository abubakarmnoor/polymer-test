'use strict';

module.exports = require('./dist/ios/PluginBase.js');
