'use strict';

// Export web by default. Other platforms have custom index.[platform].js files
module.exports = require('./dist/web/PluginBase.js');
