'use strict';

module.exports = require('./dist/android/PluginBase.js');
