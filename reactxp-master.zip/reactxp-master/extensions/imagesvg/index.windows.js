'use strict';

module.exports = require('./dist/windows/PluginBase.js');
