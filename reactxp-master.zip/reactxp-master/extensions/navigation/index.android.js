'use strict';

module.exports = require('./dist/native-common/Navigator');