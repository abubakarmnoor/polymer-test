'use strict';

module.exports = require('./dist/VirtualListView.js');
