
interface Window {
    // Allow us to put arbitrary objects in window
    [key: string]: any;
}