﻿declare module 'rebound' {
    class SpringSystem {
        createSpring(): any;
    }
}
