'use strict';

module.exports = require('./dist/macos/ReactXP.js');
