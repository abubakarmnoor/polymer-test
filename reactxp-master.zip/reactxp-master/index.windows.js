'use strict';

module.exports = require('./dist/windows/ReactXP.js');
