'use strict';

module.exports = require('./dist/android/ReactXP.js');
