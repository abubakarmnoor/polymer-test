'use strict';

module.exports = require('./dist/ios/ReactXP.js');
