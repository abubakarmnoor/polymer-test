import TodoApp = require('./TodoAppNative');

TodoApp.init();

