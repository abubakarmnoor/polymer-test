import TodoApp = require('./TodoAppWeb');

TodoApp.init();
