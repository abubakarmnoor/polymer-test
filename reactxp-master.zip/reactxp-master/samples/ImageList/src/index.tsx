import ImageApp = require('./ImageApp');

ImageApp.init();
