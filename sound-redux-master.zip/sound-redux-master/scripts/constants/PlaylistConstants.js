export const AUTHED_PLAYLIST_SUFFIX = '|authed';
export const SONG_PLAYLIST_SUFFIX = '|song';
export const USER_PLAYLIST_SUFFIX = '|user';
