import React, { Component } from 'react';

class MobileFooter extends Component {
  render() {
    return <div></div>;
  }
}

export default MobileFooter;
